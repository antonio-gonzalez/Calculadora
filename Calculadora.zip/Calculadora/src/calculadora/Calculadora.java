/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package calculadora;
import java.util.Scanner;

/**
 *
 * @author pachoca
 */
public class Calculadora {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       float[]numero;
       numero = new float[2];
        float oper, num1, num2, sum, res, mul, div,dec;
        Scanner buffer = new Scanner(System.in);
        do{
            do{
                System.out.println("INGRESE A UNA  DE NUESTRAS OPCIONES : ");
                System.out.println(" OPCION UNO : SUMA DE UNIDADES ");
                System.out.println(" OPCION DOS : RESTA DE UNIDADES");
                System.out.println(" OPCION TRES : MULTIPLICACION DE UNIDADES");
                System.out.println(" OPCION CUANTRO : DIVICION DE UNIDADES ");
                oper = buffer.nextFloat();
                if(oper>4 || oper<1)
                {
                    System.out.println("LA OPCION QUE USTED ESTA INGRESADO ESTA INCORECTA POR FAVOR INTENTE DE NUEVO: ");
                }
            }
            while (oper>4 ||oper<1);
            for (int i =0;i<numero.length;i++)
            {
                System.out.println("INGRESE SU NUMERO: "+(1+i));
                if(i==0)
                {
                    num1 = buffer.nextFloat();
                   
                }
                if(i==1)
                {
                    num2 = buffer.nextFloat();
                    
                }
            }
            if (oper==1)
            {
                sum = numero[0] + numero[1];
                System.out.println("LA SUMA QUE INGRESO ES: " + sum);
            }
            if (oper==2)
            {
                res = numero[0] - numero[1];
                System.out.println("LA RESTA QUE INGRESO ES: " + res);
            }
            if (oper==3)
            {
                mul = numero[0] * numero[1];
                System.out.println("LA MULTIPLICACION QUE INGRESO ES: " + mul);
            }
            if (oper==4)
            {
                div = numero[0] / numero[1];
                System.out.println("LA DIVICION QUE INGRESO ES: " + div);
            }
            System.out.println("QUE OTRA OPERACION VA INGRESAR: ESCOJA!!!!");
            System.out.println("OPCION UNO: SI VAMOS REALIZAR OTRA OPERACION O OPCION 2 PARA DAR POR TERMINADA LA OPERACION");
            dec = buffer.nextFloat();
        }
        while (dec==1&&dec!=2);
    }
    
    
}
